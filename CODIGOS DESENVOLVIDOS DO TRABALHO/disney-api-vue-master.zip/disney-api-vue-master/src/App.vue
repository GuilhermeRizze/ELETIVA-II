<template>
  <DisneyComponente/>
</template>

<script>
import DisneyComponente from './components/DisneyComponente.vue';

export default {
  name: "App",
  components: {
    DisneyComponente
  }
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  font-size: sans-serif;
}
</style>