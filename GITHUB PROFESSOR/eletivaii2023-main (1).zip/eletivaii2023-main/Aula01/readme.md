# Aula 01

Entendendo o funcionamento do JavaScript.
 - Trabalhando com alert
 - Trabalhando com prompt
 - Trabalhando com DOM
 - Trabalhando com variáveis

Exercício

1 - Entre com dois números faça a some e retorne no DOM o resultado.

2 - Entre com dois números, faça a soma e a subtração e retorno no DOM os dois resultados.