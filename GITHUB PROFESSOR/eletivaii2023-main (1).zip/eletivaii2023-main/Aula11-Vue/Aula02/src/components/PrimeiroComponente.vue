<template>
  <div>
    <h1>Rodrigo Escobar</h1>
    <br />
    <p>Olá mundo</p>
  </div>
</template>

<script>
export default {
  name: "PrimeiroComponente",
};
</script>
