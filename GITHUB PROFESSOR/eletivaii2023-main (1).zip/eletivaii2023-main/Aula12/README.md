npm install --save axios


axios.get(
    url
).then( retorno )