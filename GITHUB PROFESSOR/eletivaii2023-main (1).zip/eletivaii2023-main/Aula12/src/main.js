<<<<<<< HEAD
=======
import './assets/main.css'

>>>>>>> 571c88c09ac1b2aaa2a380679b3b50fbe2c74da5
import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')
