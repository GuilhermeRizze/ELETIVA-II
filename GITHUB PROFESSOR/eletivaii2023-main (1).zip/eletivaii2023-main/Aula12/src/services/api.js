<<<<<<< HEAD
import axios from 'axios'

const api = axios.create({
    baseURL: "https://pokeapi.co/api/v2"
})

export default api
=======
import axios from 'axios';

const instance = axios.create({
  baseURL: 'https://api.disneyapi.dev'
});

export default instance;
>>>>>>> 571c88c09ac1b2aaa2a380679b3b50fbe2c74da5
