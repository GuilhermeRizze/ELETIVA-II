<template>
  <main>
    <h1>HOME</h1>
  </main>
</template>
