<template>
    <h1>Teste</h1>
</template>

<script>
export default {
    name: "Teste"
}
</script>